﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        chk_mostrarSenha = New CheckBox()
        Button1 = New Button()
        txt_senha = New TextBox()
        txt_email = New TextBox()
        Label2 = New Label()
        Label3 = New Label()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(261, 129)
        Label1.Margin = New Padding(2, 0, 2, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(51, 20)
        Label1.TabIndex = 1
        Label1.Text = "EMAIL"
        ' 
        ' chk_mostrarSenha
        ' 
        chk_mostrarSenha.AutoSize = True
        chk_mostrarSenha.Location = New Point(431, 223)
        chk_mostrarSenha.Margin = New Padding(2, 3, 2, 3)
        chk_mostrarSenha.Name = "chk_mostrarSenha"
        chk_mostrarSenha.Size = New Size(151, 24)
        chk_mostrarSenha.TabIndex = 2
        chk_mostrarSenha.Text = "MOSTRAR SENHA"
        chk_mostrarSenha.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(303, 281)
        Button1.Margin = New Padding(2, 3, 2, 3)
        Button1.Name = "Button1"
        Button1.Size = New Size(95, 27)
        Button1.TabIndex = 3
        Button1.Text = "ENTRAR"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' txt_senha
        ' 
        txt_senha.Location = New Point(261, 223)
        txt_senha.Margin = New Padding(2, 3, 2, 3)
        txt_senha.Name = "txt_senha"
        txt_senha.Size = New Size(165, 27)
        txt_senha.TabIndex = 4
        ' 
        ' txt_email
        ' 
        txt_email.Location = New Point(261, 151)
        txt_email.Margin = New Padding(2, 3, 2, 3)
        txt_email.Name = "txt_email"
        txt_email.Size = New Size(165, 27)
        txt_email.TabIndex = 5
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("SimSun-ExtB", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(307, 62)
        Label2.Margin = New Padding(2, 0, 2, 0)
        Label2.Name = "Label2"
        Label2.Size = New Size(93, 30)
        Label2.TabIndex = 6
        Label2.Text = "LOGIN"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(261, 201)
        Label3.Margin = New Padding(2, 0, 2, 0)
        Label3.Name = "Label3"
        Label3.Size = New Size(57, 20)
        Label3.TabIndex = 7
        Label3.Text = "SENHA"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(730, 501)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(txt_email)
        Controls.Add(txt_senha)
        Controls.Add(Button1)
        Controls.Add(chk_mostrarSenha)
        Controls.Add(Label1)
        Margin = New Padding(2, 3, 2, 3)
        Name = "Form1"
        Text = "LOGIN"
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents chk_mostrarSenha As CheckBox
    Friend WithEvents Button1 As Button
    Friend WithEvents txt_senha As TextBox
    Friend WithEvents txt_email As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label

End Class
