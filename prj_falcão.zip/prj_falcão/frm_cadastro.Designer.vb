﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        ToolStrip1 = New ToolStrip()
        ToolStripLabel1 = New ToolStripLabel()
        txt_buscar = New ToolStripTextBox()
        ToolStripLabel2 = New ToolStripLabel()
        cmb_campo = New ToolStripComboBox()
        btn_criar = New Button()
        txt_csenha = New MaskedTextBox()
        LABEL2 = New Label()
        txt_senha = New TextBox()
        dgv_dados = New DataGridView()
        Column1 = New DataGridViewImageColumn()
        Column2 = New DataGridViewImageColumn()
        Column3 = New DataGridViewImageColumn()
        Column4 = New DataGridViewTextBoxColumn()
        Column5 = New DataGridViewTextBoxColumn()
        Column6 = New DataGridViewTextBoxColumn()
        Column7 = New DataGridViewTextBoxColumn()
        cmb_data_nasc = New DateTimePicker()
        Label1 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        txt_email = New TextBox()
        txt_cpf = New MaskedTextBox()
        txt_fone = New MaskedTextBox()
        txt_nome = New TextBox()
        ToolStrip1.SuspendLayout()
        CType(dgv_dados, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' ToolStrip1
        ' 
        ToolStrip1.ImageScalingSize = New Size(24, 24)
        ToolStrip1.Items.AddRange(New ToolStripItem() {ToolStripLabel1, txt_buscar, ToolStripLabel2, cmb_campo})
        ToolStrip1.Location = New Point(0, 0)
        ToolStrip1.Name = "ToolStrip1"
        ToolStrip1.Size = New Size(959, 28)
        ToolStrip1.TabIndex = 0
        ToolStrip1.Text = "ToolStrip1"
        ' 
        ' ToolStripLabel1
        ' 
        ToolStripLabel1.Name = "ToolStripLabel1"
        ToolStripLabel1.Size = New Size(252, 25)
        ToolStripLabel1.Text = "DIGITE O PARAMETRO DE PESQUISA"
        ' 
        ' txt_buscar
        ' 
        txt_buscar.Name = "txt_buscar"
        txt_buscar.Size = New Size(81, 28)
        ' 
        ' ToolStripLabel2
        ' 
        ToolStripLabel2.Name = "ToolStripLabel2"
        ToolStripLabel2.Size = New Size(143, 25)
        ToolStripLabel2.Text = "ESCOLHA O CAMPO"
        ' 
        ' cmb_campo
        ' 
        cmb_campo.Name = "cmb_campo"
        cmb_campo.Size = New Size(98, 28)
        ' 
        ' btn_criar
        ' 
        btn_criar.Location = New Point(361, 196)
        btn_criar.Margin = New Padding(2, 3, 2, 3)
        btn_criar.Name = "btn_criar"
        btn_criar.Size = New Size(158, 45)
        btn_criar.TabIndex = 1
        btn_criar.Text = "CRIAR CONTA"
        btn_criar.UseVisualStyleBackColor = True
        ' 
        ' txt_csenha
        ' 
        txt_csenha.Location = New Point(182, 214)
        txt_csenha.Margin = New Padding(2, 3, 2, 3)
        txt_csenha.Name = "txt_csenha"
        txt_csenha.Size = New Size(142, 27)
        txt_csenha.TabIndex = 2
        ' 
        ' LABEL2
        ' 
        LABEL2.AutoSize = True
        LABEL2.Location = New Point(9, 41)
        LABEL2.Margin = New Padding(2, 0, 2, 0)
        LABEL2.Name = "LABEL2"
        LABEL2.Size = New Size(118, 20)
        LABEL2.TabIndex = 3
        LABEL2.Text = "CPF DO CLIENTE"
        ' 
        ' txt_senha
        ' 
        txt_senha.Location = New Point(10, 214)
        txt_senha.Margin = New Padding(2, 3, 2, 3)
        txt_senha.Name = "txt_senha"
        txt_senha.Size = New Size(154, 27)
        txt_senha.TabIndex = 4
        ' 
        ' dgv_dados
        ' 
        dgv_dados.AllowUserToAddRows = False
        dgv_dados.AllowUserToDeleteRows = False
        dgv_dados.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgv_dados.Columns.AddRange(New DataGridViewColumn() {Column1, Column2, Column3, Column4, Column5, Column6, Column7})
        dgv_dados.Location = New Point(0, 262)
        dgv_dados.Margin = New Padding(2, 3, 2, 3)
        dgv_dados.Name = "dgv_dados"
        dgv_dados.ReadOnly = True
        dgv_dados.RowHeadersWidth = 62
        dgv_dados.Size = New Size(950, 164)
        dgv_dados.TabIndex = 7
        ' 
        ' Column1
        ' 
        Column1.HeaderText = "Column1"
        Column1.MinimumWidth = 6
        Column1.Name = "Column1"
        Column1.ReadOnly = True
        Column1.Width = 125
        ' 
        ' Column2
        ' 
        Column2.HeaderText = "Column2"
        Column2.MinimumWidth = 6
        Column2.Name = "Column2"
        Column2.ReadOnly = True
        Column2.Width = 125
        ' 
        ' Column3
        ' 
        Column3.HeaderText = "Column3"
        Column3.MinimumWidth = 6
        Column3.Name = "Column3"
        Column3.ReadOnly = True
        Column3.Width = 125
        ' 
        ' Column4
        ' 
        Column4.HeaderText = "Column4"
        Column4.MinimumWidth = 6
        Column4.Name = "Column4"
        Column4.ReadOnly = True
        Column4.Width = 125
        ' 
        ' Column5
        ' 
        Column5.HeaderText = "Column5"
        Column5.MinimumWidth = 6
        Column5.Name = "Column5"
        Column5.ReadOnly = True
        Column5.Width = 125
        ' 
        ' Column6
        ' 
        Column6.HeaderText = "Column6"
        Column6.MinimumWidth = 6
        Column6.Name = "Column6"
        Column6.ReadOnly = True
        Column6.Width = 125
        ' 
        ' Column7
        ' 
        Column7.HeaderText = "Column7"
        Column7.MinimumWidth = 6
        Column7.Name = "Column7"
        Column7.ReadOnly = True
        Column7.Width = 125
        ' 
        ' cmb_data_nasc
        ' 
        cmb_data_nasc.Format = DateTimePickerFormat.Short
        cmb_data_nasc.Location = New Point(755, 135)
        cmb_data_nasc.Margin = New Padding(2, 3, 2, 3)
        cmb_data_nasc.Name = "cmb_data_nasc"
        cmb_data_nasc.Size = New Size(159, 27)
        cmb_data_nasc.TabIndex = 8
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(9, 114)
        Label1.Margin = New Padding(2, 0, 2, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(137, 20)
        Label1.TabIndex = 9
        Label1.Text = "NOME DO CLIENTE"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(749, 114)
        Label3.Margin = New Padding(2, 0, 2, 0)
        Label3.Name = "Label3"
        Label3.RightToLeft = RightToLeft.No
        Label3.Size = New Size(165, 20)
        Label3.TabIndex = 10
        Label3.Text = "DATA DE NASCIMENTO"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(642, 114)
        Label4.Margin = New Padding(2, 0, 2, 0)
        Label4.Name = "Label4"
        Label4.Size = New Size(46, 20)
        Label4.TabIndex = 11
        Label4.Text = "FONE"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(295, 114)
        Label5.Margin = New Padding(2, 0, 2, 0)
        Label5.Name = "Label5"
        Label5.Size = New Size(57, 20)
        Label5.TabIndex = 12
        Label5.Text = "E-MAIL"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(9, 190)
        Label6.Margin = New Padding(2, 0, 2, 0)
        Label6.Name = "Label6"
        Label6.Size = New Size(57, 20)
        Label6.TabIndex = 13
        Label6.Text = "SENHA"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(182, 190)
        Label7.Margin = New Padding(2, 0, 2, 0)
        Label7.Name = "Label7"
        Label7.Size = New Size(144, 20)
        Label7.TabIndex = 14
        Label7.Text = "CONFIRMAR SENHA"
        ' 
        ' txt_email
        ' 
        txt_email.Location = New Point(295, 137)
        txt_email.Margin = New Padding(2, 3, 2, 3)
        txt_email.Name = "txt_email"
        txt_email.Size = New Size(332, 27)
        txt_email.TabIndex = 15
        ' 
        ' txt_cpf
        ' 
        txt_cpf.Location = New Point(9, 64)
        txt_cpf.Margin = New Padding(2, 3, 2, 3)
        txt_cpf.Mask = "999,999,999-99"
        txt_cpf.Name = "txt_cpf"
        txt_cpf.Size = New Size(118, 27)
        txt_cpf.TabIndex = 16
        txt_cpf.TextAlign = HorizontalAlignment.Center
        ' 
        ' txt_fone
        ' 
        txt_fone.Location = New Point(642, 137)
        txt_fone.Margin = New Padding(2, 3, 2, 3)
        txt_fone.Mask = "(99) 00000-0000"
        txt_fone.Name = "txt_fone"
        txt_fone.Size = New Size(100, 27)
        txt_fone.TabIndex = 17
        ' 
        ' txt_nome
        ' 
        txt_nome.Location = New Point(9, 137)
        txt_nome.Margin = New Padding(2, 3, 2, 3)
        txt_nome.Name = "txt_nome"
        txt_nome.Size = New Size(272, 27)
        txt_nome.TabIndex = 18
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(959, 437)
        Controls.Add(txt_nome)
        Controls.Add(txt_fone)
        Controls.Add(txt_cpf)
        Controls.Add(txt_email)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label1)
        Controls.Add(cmb_data_nasc)
        Controls.Add(dgv_dados)
        Controls.Add(txt_senha)
        Controls.Add(LABEL2)
        Controls.Add(txt_csenha)
        Controls.Add(btn_criar)
        Controls.Add(ToolStrip1)
        Margin = New Padding(2, 3, 2, 3)
        Name = "Form2"
        Text = "CADASTRO"
        ToolStrip1.ResumeLayout(False)
        ToolStrip1.PerformLayout()
        CType(dgv_dados, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents btn_criar As Button
    Friend WithEvents txt_csenha As MaskedTextBox
    Friend WithEvents LABEL2 As Label
    Friend WithEvents txt_senha As TextBox
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents txt_buscar As ToolStripTextBox
    Friend WithEvents ToolStripLabel2 As ToolStripLabel
    Friend WithEvents cmb_campo As ToolStripComboBox
    Friend WithEvents dgv_dados As DataGridView
    Friend WithEvents cmb_data_nasc As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents txt_email As TextBox
    Friend WithEvents txt_cpf As MaskedTextBox
    Friend WithEvents txt_fone As MaskedTextBox
    Friend WithEvents txt_nome As TextBox
    Friend WithEvents Column1 As DataGridViewImageColumn
    Friend WithEvents Column2 As DataGridViewImageColumn
    Friend WithEvents Column3 As DataGridViewImageColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
End Class
