﻿Imports System.Numerics
Imports ADODB
Imports MySql.Data.MySqlClient

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conecta_banco_mysql()
    End Sub


    Private Sub chk_mostrarSenha_CheckedChanged(sender As Object, e As EventArgs) Handles chk_mostrarSenha.CheckedChanged
        If chk_mostrarSenha.Checked Then
            ' Mostrar a senha
            txt_senha.UseSystemPasswordChar = False
        Else
            ' Ocultar a senha
            txt_senha.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub txt_senha_TextChanged(sender As Object, e As EventArgs) Handles txt_senha.TextChanged
        txt_senha.UseSystemPasswordChar = True
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            If txt_email.Text = "" Or txt_senha.Text = "" Then
                MsgBox("Preencha todos os campos.", MsgBoxStyle.Exclamation, "Aviso")
                txt_email.Focus()
                Exit Sub
            End If


            If txt_email.Text = "admin" And txt_senha.Text = "admin" Then
                MsgBox("ADM logado com sucesso", MsgBoxStyle.Information, "Aviso")
                Form4.Show()
                Form4.btn_cconta.Visible = True
                Me.Hide()
                Exit Sub
            End If


            sql = "SELECT * FROM tb_cliente WHERE email = '" & txt_email.Text.Replace("'", "''") & "'"
            rs = db.Execute(sql)

            If rs.EOF Then
                MsgBox("Usuário não encontrado!", MsgBoxStyle.Exclamation, "Erro")
                txt_email.Clear()
                txt_senha.Clear()
                txt_email.Focus()
                Exit Sub
            End If


            Dim senhaBanco As String = rs.Fields("senha").Value.ToString()
            If txt_senha.Text <> senhaBanco Then
                MsgBox("Senha incorreta!", MsgBoxStyle.Exclamation, "Erro")
                txt_email.Clear()
                txt_senha.Clear()
                txt_senha.Focus()
                Exit Sub
            End If


            Dim statusBanco As String = rs.Fields("status").Value.ToString()
            If statusBanco.ToLower() = "bloqueado" Then
                MsgBox("Conta bloqueada! Entre em contato com o administrador.", MsgBoxStyle.Critical, "Acesso negado")
                txt_email.Clear()
                txt_senha.Clear()
                Exit Sub
            End If


            MsgBox("Login realizado com sucesso!", MsgBoxStyle.Information, "Bem-vindo")
            Form4.Show()
            Form4.btn_cconta.Visible = False
            Me.Hide()

        Catch ex As Exception
            MsgBox("Erro ao tentar logar: " & ex.Message, MsgBoxStyle.Critical, "Erro")
        End Try
    End Sub
End Class


