﻿Imports Org.BouncyCastle.Ocsp

Public Class Form4
    Private Sub btn_cconta_Click(sender As Object, e As EventArgs) Handles btn_cconta.Click
        Form2.Show()
    End Sub

    Private Sub btn_encerrar_Click(sender As Object, e As EventArgs) Handles btn_encerrar.Click
        resp = MessageBox.Show("Deseja realmente encerrar o sistema?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If resp = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub
End Class