﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btn_cconta = New Button()
        Label1 = New Label()
        Label2 = New Label()
        btn_encerrar = New Button()
        SuspendLayout()
        ' 
        ' btn_cconta
        ' 
        btn_cconta.Location = New Point(125, 180)
        btn_cconta.Margin = New Padding(2)
        btn_cconta.Name = "btn_cconta"
        btn_cconta.Size = New Size(142, 45)
        btn_cconta.TabIndex = 0
        btn_cconta.Text = "CRIAR CONTA"
        btn_cconta.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Bodoni MT Condensed", 48F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(298, 60)
        Label1.Name = "Label1"
        Label1.Size = New Size(177, 93)
        Label1.TabIndex = 1
        Label1.Text = "MENU"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Poor Richard", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(298, 25)
        Label2.Name = "Label2"
        Label2.Size = New Size(177, 35)
        Label2.TabIndex = 2
        Label2.Text = "BEM VINDO"
        ' 
        ' btn_encerrar
        ' 
        btn_encerrar.Location = New Point(540, 180)
        btn_encerrar.Margin = New Padding(2)
        btn_encerrar.Name = "btn_encerrar"
        btn_encerrar.Size = New Size(142, 45)
        btn_encerrar.TabIndex = 3
        btn_encerrar.Text = "ENCERRAR"
        btn_encerrar.UseVisualStyleBackColor = True
        ' 
        ' Form4
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(781, 360)
        Controls.Add(btn_encerrar)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btn_cconta)
        Margin = New Padding(2)
        Name = "Form4"
        Text = "MENU"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btn_cconta As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btn_encerrar As Button
End Class
