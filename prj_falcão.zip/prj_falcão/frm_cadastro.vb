﻿Imports MySql.Data.MySqlClient

Public Class Form2

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        configurar_dgv()
        carregar_dados()
        limpar_campos()
        carregar_tipo_dados()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Form4.Show()
    End Sub

    Private Sub btn_criar_Click(sender As Object, e As EventArgs) Handles btn_criar.Click
        Try

            sql = $"SELECT * FROM tb_cliente WHERE cpf = '{txt_cpf.Text.Replace("'", "''")}'"
            rs = db.Execute(sql)

            If Not rs.EOF Then
                sql = $"UPDATE tb_cliente SET " &
                      $"nome = '{txt_nome.Text.Replace("'", "''")}', " &
                      $"data_nasc = '{cmb_data_nasc.Value.ToShortDateString()}', " &
                      $"fone = '{txt_fone.Text.Replace("'", "''")}', " &
                      $"email = '{txt_email.Text.Replace("'", "''")}', " &
                      $"senha = '{txt_senha.Text.Replace("'", "''")}' " &
                      $"WHERE cpf = '{txt_cpf.Text.Replace("'", "''")}'"
                db.Execute(sql)
                MsgBox("Dados alterados com sucesso!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")
            Else
                If txt_senha.Text <> txt_csenha.Text Then
                    MsgBox("As senhas não coincidem.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Erro")
                    txt_senha.Clear()
                    txt_csenha.Clear()
                    txt_senha.Focus()
                    Exit Sub
                End If

                sql = $"INSERT INTO tb_cliente (cpf,nome,data_nasc,fone,email,senha) VALUES (" &
                      $"'{txt_cpf.Text.Replace("'", "''")}', " &
                      $"'{txt_nome.Text.Replace("'", "''")}', " &
                      $"'{cmb_data_nasc.Value.ToShortDateString()}', " &
                      $"'{txt_fone.Text.Replace("'", "''")}', " &
                      $"'{txt_email.Text.Replace("'", "''")}', " &
                      $"'{txt_senha.Text.Replace("'", "''")}')"
                db.Execute(sql)
                MsgBox("Dados gravados com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            End If

            carregar_dados()
            limpar_campos()

        Catch ex As Exception
            MsgBox("Erro ao gravar! " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

    Public Sub carregar_dados()
        Try
            dgv_dados.Rows.Clear()

            sql = "SELECT cpf, email, senha, status FROM tb_cliente"
            rs = db.Execute(sql)

            Do While Not rs.EOF

                dgv_dados.Rows.Add(Nothing, Nothing, Nothing,
                                   rs.Fields("cpf").Value,
                                   rs.Fields("email").Value,
                                   rs.Fields("senha").Value,
                                   rs.Fields("status").Value)
                rs.MoveNext()
            Loop


            For Each linha As DataGridViewRow In dgv_dados.Rows
                If linha.Cells("status").Value IsNot Nothing AndAlso linha.Cells("status").Value.ToString() = "Bloqueado" Then
                    linha.Cells("status").Style.ForeColor = Color.Red
                Else
                    linha.Cells("status").Style.ForeColor = Color.Green
                End If
            Next

        Catch ex As Exception
            MsgBox("Erro ao carregar dados: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub dgv_dados_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_dados.CellContentClick
        Try

            If e.RowIndex < 0 Then Exit Sub


            Dim cpf As String = dgv_dados.Rows(e.RowIndex).Cells("cpf").Value.ToString()

            Select Case dgv_dados.Columns(e.ColumnIndex).Name
                Case "editar"

                    sql = $"SELECT * FROM tb_cliente WHERE cpf='{cpf}'"
                    rs = db.Execute(sql)

                    If Not rs.EOF Then
                        txt_cpf.Text = rs.Fields("cpf").Value
                        txt_nome.Text = rs.Fields("nome").Value
                        txt_fone.Text = rs.Fields("fone").Value
                        txt_email.Text = rs.Fields("email").Value
                        txt_senha.Text = rs.Fields("senha").Value
                        txt_csenha.Text = rs.Fields("senha").Value
                    End If

                Case "excluir"

                    If MsgBox("Deseja realmente excluir este cliente?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmação") = MsgBoxResult.Yes Then
                        sql = $"DELETE FROM tb_cliente WHERE cpf='{cpf}'"
                        rs = db.Execute(sql)
                        carregar_dados()
                    End If

                Case "bloquear"

                    If MsgBox("Deseja bloquear/desbloquear este cliente?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmação") = MsgBoxResult.Yes Then
                        sql = $"UPDATE tb_cliente SET status = IF(status='Ativo','Bloqueado','Ativo') WHERE cpf='{cpf}'"
                        rs = db.Execute(sql)
                        carregar_dados()
                    End If
            End Select

        Catch ex As Exception
            MsgBox("Erro ao processar clique: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub txt_cpf_DoubleClick(sender As Object, e As EventArgs) Handles txt_cpf.DoubleClick
        limpar_campos()
    End Sub

    Private Sub txt_buscar_TextChanged(sender As Object, e As EventArgs) Handles txt_buscar.TextChanged
        Try
            sql = $"SELECT cpf, email, senha, status FROM tb_cliente WHERE {cmb_campo.Text} LIKE '{txt_buscar.Text.Replace("'", "''")}%'"
            rs = db.Execute(sql)
            cont = 1
            dgv_dados.Rows.Clear()
            Do While Not rs.EOF

                dgv_dados.Rows.Add(Nothing, Nothing, Nothing,
                                   rs.Fields("cpf").Value,
                                   rs.Fields("email").Value,
                                   rs.Fields("senha").Value,
                                   rs.Fields("status").Value)
                rs.MoveNext()
                cont += 1
            Loop
        Catch ex As Exception
            MsgBox("Erro na busca: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub txt_cpf_LostFocus(sender As Object, e As EventArgs) Handles txt_cpf.LostFocus
        Try
            sql = $"SELECT * FROM tb_cliente WHERE cpf = '{txt_cpf.Text.Replace("'", "''")}'"
            rs = db.Execute(sql)
            If Not rs.EOF Then
                txt_nome.Text = If(IsDBNull(rs.Fields("nome").Value), "", rs.Fields("nome").Value.ToString())
                txt_fone.Text = If(IsDBNull(rs.Fields("fone").Value), "", rs.Fields("fone").Value.ToString())
                txt_email.Text = If(IsDBNull(rs.Fields("email").Value), "", rs.Fields("email").Value.ToString())
                txt_senha.Text = If(IsDBNull(rs.Fields("senha").Value), "", rs.Fields("senha").Value.ToString())
            Else
                txt_nome.Focus()
            End If
        Catch ex As Exception
            MsgBox("Erro ao consultar! " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

    Private Sub txt_buscar_Click(sender As Object, e As EventArgs) Handles txt_buscar.Click

    End Sub

    Private Sub configurar_dgv()
        dgv_dados.Columns.Clear()


        Dim colEditar As New DataGridViewImageColumn()
        colEditar.HeaderText = "EDTAR"
        colEditar.Name = "editar"
        dgv_dados.Columns.Add(colEditar)


        Dim colExcluir As New DataGridViewImageColumn()
        colExcluir.HeaderText = "EXCLUIR"
        colExcluir.Name = "excluir"
        dgv_dados.Columns.Add(colExcluir)

        Dim colBloquear As New DataGridViewImageColumn()
        colBloquear.HeaderText = "BLOQUEAR"
        colBloquear.Name = "bloquear"
        dgv_dados.Columns.Add(colBloquear)


        dgv_dados.Columns.Add("cpf", "CPF")
        dgv_dados.Columns.Add("email", "Email")
        dgv_dados.Columns.Add("senha", "Senha")
        dgv_dados.Columns.Add("status", "Status")

        dgv_dados.RowTemplate.Height = 32
        dgv_dados.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill


        dgv_dados.Columns("status").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    End Sub

    Private Sub limpar_campos()
        txt_cpf.Clear()
        txt_nome.Clear()
        cmb_data_nasc.Value = Now
        txt_fone.Clear()
        txt_email.Clear()
        txt_senha.Clear()
        txt_csenha.Clear()
        txt_cpf.Focus()
    End Sub

End Class
