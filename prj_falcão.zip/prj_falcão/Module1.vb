﻿Imports MySql.Data.MySqlClient
Module Module1
    Public db As New ADODB.Connection
    Public rs As New ADODB.Recordset
    Public diretorio, sql, aux_cpf, resp As String
    Public cont As Integer




    Sub conecta_banco_mysql()
        Try
            db = CreateObject("ADODB.Connection")
            db.Open("DRIVER={MySQL ODBC 3.51 Driver};SERVER=localhost;DATABASE=clientes;UID=root;PWD=usbw;port=3307;option=3;")
            MsgBox("Conexão OK", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        Catch ex As Exception
            MsgBox("Erro ao Conectar: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub





    Sub carregar_tipo_dados()
        With Form2.cmb_campo.Items
            .Add("CPF")
            .Add("NOME")
        End With
        Form2.cmb_campo.SelectedIndex = 1
    End Sub

End Module
